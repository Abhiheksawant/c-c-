class Loan
{
	private:
		double principle;
		double period;

	public:
		Loan()
		{
		principle = 0;
		period = 0;
		}

		Loan(double p1, double p2)
		{
		principle = p1;
		period= p2;	
		}

		GetPrinciple()
		{
		return principle;
		}
		GetPeriod()
		{
		return period;
		}

		void SetPrinciple(double p1)
		{
		principle =p1;
		}
		void SetPeriod(double p2)
		{
		period = p2;
		}

		virtual double GetRate()=0;

		double GetEMI()
		{
		double emi;
		emi = principle*(1+r*period/100)/(12*period);

		}

};
/*class HomeLoan : public Loan
	{
		private: 
	
	}
*/


int main()
{


}
